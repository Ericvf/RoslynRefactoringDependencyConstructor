﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using static Microsoft.CodeAnalysis.CSharp.SyntaxFactory;

namespace DependencyConstructor
{
    public static class TaskHelpers
    {
        public static MethodDeclarationSyntax GenerateSync(MethodDeclarationSyntax oldMethod)
        {
            var returnType = oldMethod.ReturnType as GenericNameSyntax;
            if (returnType?.Identifier.ValueText == "Task" && returnType.TypeArgumentList.Arguments.Count() == 1)
            {
                var newReturnType = returnType.TypeArgumentList.Arguments.Single();

                var newModifiers = oldMethod.Modifiers
                    .Where(m => !m.IsKind(SyntaxKind.AsyncKeyword));

                return oldMethod
                    .WithModifiers(TokenList(newModifiers))
                    .WithReturnType(
                        newReturnType.WithTrailingTrivia(oldMethod.ReturnType.GetTrailingTrivia()));
            }
            else
                return oldMethod;
        }

        public static MethodDeclarationSyntax GenerateAsync(MethodDeclarationSyntax oldMethod)
        {
            var ws = SyntaxTrivia(SyntaxKind.WhitespaceTrivia, " ");

            TypeSyntax returnType;
            if (oldMethod.ReturnType.IsKind(SyntaxKind.PredefinedType)
                && ((PredefinedTypeSyntax)oldMethod.ReturnType).Keyword.IsKind(SyntaxKind.VoidKeyword))
            {
                returnType = IdentifierName(Identifier("Task"))
                    .WithTrailingTrivia(ws);
            }
            else
                returnType = GenericName(Identifier("Task"))
                    .WithTypeArgumentList(TypeArgumentList(
                        SingletonSeparatedList(oldMethod.ReturnType
                            .WithoutTrailingTrivia()))
                    ).WithTrailingTrivia(ws);

            var newModifiers = oldMethod.Modifiers.ToList();
            newModifiers.Add(Token(SyntaxKind.AsyncKeyword).WithTrailingTrivia(ws));

            return oldMethod
                .WithModifiers(TokenList(newModifiers))
                .WithReturnType(returnType);
        }

        public static bool HasConvertToSynchronous(MethodDeclarationSyntax methodDeclaration, SemanticModel semanticModel)
        {

            if (methodDeclaration.Modifiers.Any(m => m.IsKind(SyntaxKind.AsyncKeyword)))
            {
                var taskType = semanticModel.Compilation.GetTypeByMetadataName("System.Threading.Tasks.Task");
                if (methodDeclaration.ReturnType != taskType)
                {
                    return true;
                }
            }

            return false;
        }

        public static bool HasConvertToAsynchronous(MethodDeclarationSyntax methodDeclaration, SemanticModel semanticModel)
        {
            if (!methodDeclaration.Modifiers.Any(m => m.IsKind(SyntaxKind.AsyncKeyword)))
            {
                return true;
            }

            return false;
        }
    }

    public class GenerateDependencyConstructorHelpers
    {
        public static ClassDeclarationSyntax GenerateDependencyConstructor(ClassDeclarationSyntax currentClassNode)
        {
            // Get the current constructor, if it has one
            var currentConstructorNode = currentClassNode.DescendantNodes()
                .OfType<ConstructorDeclarationSyntax>()
                .FirstOrDefault();

            // Create list of current constructor argument names
            var currentConstructorArguments = currentConstructorNode?
                .ParameterList.DescendantNodes()
                .OfType<ParameterSyntax>()
                .Select(p => p.Identifier.Text);

            // Create a list of all the readonly members
            var dependencyMembersAndParameterNames =
                from memberField in currentClassNode.DescendantNodes().OfType<FieldDeclarationSyntax>()
                where memberField.Modifiers.Any(m => m.IsKind(SyntaxKind.ReadOnlyKeyword))
                let fieldType = memberField.Declaration.Type
                from variable in memberField.Declaration.Variables
                let fieldName = variable.Identifier.ValueText
                let parameterName = fieldName.StartsWith("_")
                     ? fieldName.Substring(1)
                     : "_" + fieldName
                select new { fieldType, variable, fieldName, parameterName };

            // Create a list of the new constructor arguments, exclude those already present
            var newParameterSyntaxList = (
                from vars in dependencyMembersAndParameterNames
                where currentConstructorArguments == null || !currentConstructorArguments.Contains(vars.parameterName)
                select Parameter(Identifier(vars.parameterName))
                    .WithType(vars.fieldType));

            IEnumerable<string> currentConstructorAssignedMembers = new List<string>();
            if (currentConstructorNode != null)
            {
                var dependencyMemberNames = dependencyMembersAndParameterNames.Select(c => c.fieldName);

                // Create a list of all members names that are already assigned
                currentConstructorAssignedMembers =
                    from statement in currentConstructorNode.Body.Statements
                    let expression = statement as ExpressionStatementSyntax
                    let assignment = expression?.Expression as AssignmentExpressionSyntax
                    let leftMember = assignment?.Left as IdentifierNameSyntax
                    where leftMember != null && dependencyMemberNames.Contains(leftMember.Identifier.ValueText)
                    select leftMember.Identifier.ValueText;
            }

            // Create a list of the new constructor statements, exclude those already assigned
            var newStatementSyntaxList =
                from vars in dependencyMembersAndParameterNames
                where !currentConstructorAssignedMembers.Contains(vars.fieldName)
                let leftMember = IdentifierName(vars.fieldName)
                let rightMember = IdentifierName(vars.parameterName)
                let expression = AssignmentExpression(SyntaxKind.SimpleAssignmentExpression, leftMember, rightMember)
                select ExpressionStatement(expression);

            // Check if we need to create a new constructor
            if (currentConstructorNode == null)
            {
                // Create new constructor
                var newConstructorNode = ConstructorDeclaration(currentClassNode.Identifier.ValueText)
                    .WithModifiers(TokenList(Token(SyntaxKind.PublicKeyword)))
                    .WithParameterList(ParameterList(SeparatedList(newParameterSyntaxList)))
                    .WithBody(Block(newStatementSyntaxList)
                        .WithTrailingTrivia(CarriageReturnLineFeed));

                // Add it to the class 
                currentClassNode = currentClassNode.AddMembers(newConstructorNode);
            }
            else
            {
                var currentConstructorTrivia = currentConstructorNode.Body.GetTrailingTrivia();

                // Add the constructor arguments and statements
                var newConstructorNode = currentConstructorNode.AddParameterListParameters(newParameterSyntaxList.ToArray());
                newConstructorNode = newConstructorNode.AddBodyStatements(newStatementSyntaxList.ToArray());

                // Replace the constructor in the class
                currentClassNode = currentClassNode.ReplaceNode(currentConstructorNode, newConstructorNode);
            }

            return currentClassNode.NormalizeWhitespace();
        }
    }
}