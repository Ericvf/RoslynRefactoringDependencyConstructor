using System.Composition;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CodeActions;
using Microsoft.CodeAnalysis.CodeRefactorings;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace DependencyConstructor
{
    [ExportCodeRefactoringProvider(LanguageNames.CSharp, Name = nameof(DependencyConstructorCodeRefactoringProvider)), Shared]
    public class DependencyConstructorCodeRefactoringProvider : CodeRefactoringProvider
    {
        public sealed override async Task ComputeRefactoringsAsync(CodeRefactoringContext context)
        {
            var root = await context.Document.GetSyntaxRootAsync(context.CancellationToken).ConfigureAwait(false);
            var node = root.FindNode(context.Span);

            ClassDeclarationSyntax classDeclaration = null;
            switch (node.Kind())
            {
                case SyntaxKind.ConstructorDeclaration:
                    classDeclaration = node.Parent as ClassDeclarationSyntax;
                    break;

                case SyntaxKind.ClassDeclaration:
                    classDeclaration = node as ClassDeclarationSyntax;
                    break;
            }

            if (classDeclaration != null)
            {
                var action = CodeAction.Create("Resolve unassigned dependencies", c =>
                    GenerateDependencyConstructorAction(context.Document, classDeclaration, c));

                context.RegisterRefactoring(action);
            }
        }

        public async Task<Document> GenerateDependencyConstructorAction(Document document, ClassDeclarationSyntax oldNode, CancellationToken cancellationToken)
        {
            var oldRoot = await document.GetSyntaxRootAsync(cancellationToken).ConfigureAwait(false);

            var newNode = GenerateDependencyConstructorHelpers.GenerateDependencyConstructor(oldNode);
            var newRoot = oldRoot.ReplaceNode(oldNode, newNode);

            return document.WithSyntaxRoot(newRoot);
        }
    }

    [ExportCodeRefactoringProvider(LanguageNames.CSharp, Name = nameof(TaskCodeRefactoringProvider)), Shared]
    public class TaskCodeRefactoringProvider : CodeRefactoringProvider
    {
        public sealed override async Task ComputeRefactoringsAsync(CodeRefactoringContext context)
        {
            var root = await context.Document.GetSyntaxRootAsync(context.CancellationToken).ConfigureAwait(false);
            var node = root.FindNode(context.Span);

            var methodDeclaration = node as MethodDeclarationSyntax;
            if (methodDeclaration != null)
            {
                var semanticModel = await context.Document.GetSemanticModelAsync();
                if (TaskHelpers.HasConvertToSynchronous(methodDeclaration, semanticModel))
                {
                    var action = CodeAction.Create("Convert async to synchronous method", c =>
                        GenerateSyncMethodRefactorings(context.Document, methodDeclaration, c));

                    context.RegisterRefactoring(action);
                }
                if (TaskHelpers.HasConvertToAsynchronous(methodDeclaration, semanticModel))
                {
                    var action = CodeAction.Create("Convert to asynchronous method", c =>
                        GenerateAsyncMethodRefactorings(context.Document, methodDeclaration, c));

                    context.RegisterRefactoring(action);
                }
            }
        }

        public async Task<Document> GenerateAsyncMethodRefactorings(Document document, MethodDeclarationSyntax oldNode, CancellationToken cancellationToken)
        {
            var oldRoot = await document.GetSyntaxRootAsync(cancellationToken).ConfigureAwait(false);

            var newNode = TaskHelpers.GenerateAsync(oldNode);
            var newRoot = oldRoot.ReplaceNode(oldNode, newNode);

            return document.WithSyntaxRoot(newRoot);
        }

        public async Task<Document> GenerateSyncMethodRefactorings(Document document, MethodDeclarationSyntax oldNode, CancellationToken cancellationToken)
        {
            var oldRoot = await document.GetSyntaxRootAsync(cancellationToken).ConfigureAwait(false);

            var newNode = TaskHelpers.GenerateSync(oldNode);
            var newRoot = oldRoot.ReplaceNode(oldNode, newNode);

            return document.WithSyntaxRoot(newRoot);
        }
    }
}
